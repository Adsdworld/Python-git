Liste=[]
Liste.insert(0, "k")
print (Liste)