from random import randint

#
def random(Liste):
    return Liste[randint(0, len(Liste)-1)]