import ModuleFonctions as MF
import os

# clear the console screen
if os.name == 'nt':
    os.system('cls')
else:
    os.system('clear')

print(MF.MP.variable)

MF.function(1)
print("______________________________")
MF.function(0)


"""
Examen 1 - 12 octobre 2023
Accès restreint Disponible à partir du 12 octobre 2023, 08:55
Cet examen durera 1 heure et comprend :

un QCM de 20 questions (temps maximum : 30 minutes)
un programme constitué d'un mini programme et de 4 fonctions à développer.


PRENEZ le temps de lire le sujet jusqu'au bout pour voir/comprendre quel est le résultat attendu

ATTENTION à bien mettre votre nom/prénom en commentaire de CHACUN des fichiers à rendre (Sinon -1 point)

ATTENTION à bien rendre TOUS les fichiers attendus (Sinon, perte de points)



https://github.com/Adsdworld/Python-git/blob/main/entrainement%20control.py

https://github.com/Adsdworld/Python-git/blob/main/entrainement%20control%20-%20Corrig%C3%A9.py
"""