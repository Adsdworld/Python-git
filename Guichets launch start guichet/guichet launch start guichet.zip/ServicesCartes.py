DatabaseSolde=500
DatabaseCard=1
DatabaseCode=1234
DatabaseMaximuWithdrawAmout=100
TicketMsg=""

def RécupérerCode():
    return DatabaseCode
def RécupérerSolde():
    return DatabaseSolde
def récupérerSoldehebdo():
    return DatabaseMaximuWithdrawAmout


