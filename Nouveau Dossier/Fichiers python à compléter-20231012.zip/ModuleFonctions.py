# NOM PRENOM
# Examen du 12/10/2023
# Module Fonctions

# Fonction qui renvoie le résultat d'une division
# Contrôler la saisie de l'utilisateur et gérer les exceptions pouvant survenir
# lorsque cette fonction est appelée
def fonction1() :
    # saisir un premier entier entre 2 et 12
    
    # saisir un second entier
    
    # effectuer la division
    
    # afficher le résultat de la division
    

# Fonction qui fait saisir 10 mots à l'utilisateur, qui les stocke dans une liste
# puis qui retourne cette liste
def fonction2() :

    # créer une liste qui contient des mots (au moins 10) 
   
    # retourner la liste


# Fonction qui retourne un mot pris au hasard dans une liste
# La liste est récupérée en paramètre
def fonction3() :

    # récupérer un mot de la liste au hasard
   
    # retourner la liste


# Fonction qui recherche un caractère dans une chaine de caractères
# Cette fonction prend en paramètre une liste déjà remplie de mots
# et va utiliser la fonction3 pour récupérer un mot de la liste au hasard
# L'utilisateur va saisir une lettre
# La fonction va retourner vrai si le caractère est présent dans le mot et faux sinon
def fonction4() :
    # faire saisir un caractère - avec les contrôles nécessaires

    # récupérer au hasard d'un mot de la liste


    # retourner le résultat de la recherche



