# NOM PRENOM
# Programme Principal qui va appeler les fonctions du module ModuleFonctions
# et le programme du module MiniProgramme

# Appel du programme de consommation automobile


# Appel de la fonction1


# Appel de la fonction2


# Appel de la fonction3


# Appel de la fonction4 et affichage du résultat





